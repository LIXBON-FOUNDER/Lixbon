// AttentionInbox.jsx — "¿Qué necesita de mí AHORA?"  Attention es pequeña y accionable; Activity (telemetría) vive aparte.
import { useState } from 'react';
import { useStore, attemptById, timelineOf } from '../store';
import AttentionCard from './AttentionCard';
import { I, Mark } from '../ui';

const GROUPS = [
  { id: 'block', title: 'Blocking an agent', kinds: ['permission', 'question', 'security'], hint: 'The agent cannot continue until you answer.' },
  { id: 'review', title: 'Ready for your review', kinds: ['review'], hint: 'Evidence first, diff second.' },
  { id: 'problems', title: 'Problems', kinds: ['failed', 'conflict', 'host'], hint: 'Something broke or is unreachable.' },
];
const RISK_ORDER = { high: 0, medium: 1, low: 2, none: 3 };

export function ActivityFeed({ limit = 12 }) {
  const s = useStore();
  return (
    <aside className="feed" aria-label="Activity">
      <header className="feed__h"><h3>Activity</h3><span className="muted">telemetry · asks nothing of you</span></header>
      <ol>
        {s.activity.slice(0, limit).map((x) => (
          <li key={x.id}>
            <button type="button" onClick={() => x.attemptId && s.select(x.attemptId)}>
              <span className={`feed__dot feed__dot--${x.tone}`} /><span className="grow">{x.text}</span><time>{x.time}</time>
            </button>
          </li>
        ))}
      </ol>
    </aside>
  );
}

export default function AttentionInbox() {
  const s = useStore();
  const [picked, setPicked] = useState([]);
  const items = [...s.attention];
  const batchable = items.filter((x) => x.kind === 'permission' && x.risk === 'low');
  const toggle = (id) => setPicked((p) => (p.includes(id) ? p.filter((x) => x !== id) : [...p, id]));
  const approveBatch = () => { picked.forEach((id) => s.resolveAttention(id, 'allow_once', { from: 'ADE' })); s.toast(`Allowed ${picked.length} low-risk commands once.`, 'good'); setPicked([]); };

  return (
    <div className="inbox">
      <div className="inbox__main">
        <header className="inbox__h">
          <h1>Attention</h1>
          <span className="muted">{items.length} need{items.length === 1 ? 's' : ''} a human decision</span>
          <span className="sp" />
          <button type="button" className="btn btn--text btn--sm" onClick={() => items.filter((i) => i.kind === 'host').forEach((i) => s.resolveAttention(i.id, 'snooze'))}>Snooze host alerts</button>
        </header>
        {items.length === 0 && <div className="empty">Nothing needs you. Agents are working inside their contracts.</div>}
        {batchable.length > 1 && (
          <div className="callout callout--info inbox__batch">
            <b>Batch triage</b> — {batchable.length} low-risk permissions are identical in kind.
            <span className="sp" />
            <button type="button" className="btn btn--ghost btn--sm" onClick={() => setPicked(batchable.map((b) => b.id))}>Select all low-risk</button>
            <button type="button" className="btn btn--accent btn--sm" disabled={!picked.length} onClick={approveBatch}>Allow once ({picked.length})</button>
          </div>
        )}
        {GROUPS.map((g) => {
          const list = items.filter((x) => g.kinds.includes(x.kind)).sort((a, b) => RISK_ORDER[a.risk] - RISK_ORDER[b.risk]);
          if (!list.length) return null;
          return (
            <section key={g.id} className="inbox__g">
              <h2>{g.title} <i>{list.length}</i><span className="muted"> · {g.hint}</span></h2>
              {list.map((x) => <AttentionCard key={x.id} item={x} selectable={x.kind === 'permission' && x.risk === 'low'} selected={picked.includes(x.id)} onSelect={toggle} />)}
            </section>
          );
        })}
        <p className="muted inbox__foot"><I n="shield" size={12} /> High-impact or destructive approvals are never batched. A temporary permission never silently becomes a global one.</p>
      </div>
      <ActivityFeed />
    </div>
  );
}
