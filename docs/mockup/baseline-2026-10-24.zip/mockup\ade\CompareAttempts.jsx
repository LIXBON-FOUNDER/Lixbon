// CompareAttempts.jsx — dos (o más) Attempts de la MISMA Task, con el MISMO ContextPackage, lado a lado.
import { useState } from 'react';
import { useStore, attemptsOfTask, taskOf, attemptById } from '../store';
import { PROOF_PACKS } from '../data';
import { Agent, Loc, StatePill, I, money } from '../ui';

const APPROACH = {
  att_oa_a: 'Rotates refresh tokens in place and keeps a sliding-expiry fallback. Still thinking about live-session compatibility.',
  att_oa_b: PROOF_PACKS.att_oa_b.approach,
  att_rt_a: 'Event-sourced state machine; worktree manager resolves paths through ProjectLocation.',
  att_rt_b: PROOF_PACKS.att_rt_b.approach,
};
const WARN = { att_oa_a: 0, att_oa_b: 1, att_rt_a: 0, att_rt_b: 3 };

function best(vals, dir) {
  const v = vals.filter((x) => x != null);
  if (v.length < 2) return -1;
  const t = dir === 'min' ? Math.min(...v) : Math.max(...v);
  return vals.filter(x => x === t).length > 1 ? -1 : vals.indexOf(t);
}

export default function CompareAttempts() {
  const s = useStore();
  const cur = attemptById(s, s.sel.attemptId);
  const task = taskOf(s, cur);
  const atts = attemptsOfTask(s, task.id);
  const [msg, setMsg] = useState('');
  if (atts.length < 2) {
    return (
      <div className="pad">
        <h1 className="v-title">Compare Attempts</h1>
        <div className="empty">“{task.title}” has a single Attempt. <button type="button" className="btn btn--accent btn--sm" onClick={() => s.openFork(cur.id)}>Fork as Attempt</button> to try a different agent from the same ContextPackage.</div>
      </div>
    );
  }
  const rows = [
    ['Approach', atts.map((a) => <p key={a.id} className="cmpv__p">{APPROACH[a.id] || 'Approach summary available when the Attempt finishes.'}</p>)],
    ['Files changed', atts.map((a) => a.files), best(atts.map((a) => a.files), 'min'), (v) => `${v} files`],
    ['Lines', atts.map((a) => <span key={a.id}><b className="good">+{a.add}</b> <b className="danger">−{a.del}</b></span>)],
    ['Tests', atts.map((a) => (a.tests ? a.tests.pass / a.tests.total : null)), best(atts.map((a) => (a.tests ? a.tests.pass / a.tests.total : null)), 'max'), (v, a) => (a.tests ? `${a.tests.pass}/${a.tests.total}` : '—')],
    ['Time', atts.map((a) => a.minutes), best(atts.map((a) => a.minutes), 'min'), (v) => `${v} min`],
    ['Usage', atts.map((a) => a.cost), best(atts.map((a) => a.cost), 'min'), (v, a) => `${money(v)} · ${(a.tokens / 1000).toFixed(0)}k tok`],
    ['Warnings', atts.map((a) => WARN[a.id] ?? 0), best(atts.map((a) => WARN[a.id] ?? 0), 'min'), (v) => (v ? `${v} warning${v > 1 ? 's' : ''}` : 'none')],
    ['Risks', atts.map((a) => { const p = PROOF_PACKS[a.id]; return p ? <span key={a.id} className="row" style={{ gap: 4, flexWrap: 'wrap' }}>{p.risks.map((r, i) => <span key={i} className={`risk risk--${r.level}`}>{r.level}</span>)}</span> : <span key={a.id} className="muted">not assessed yet</span>; })],
    ['Result', atts.map((a) => <StatePill key={a.id} attempt={a} />)],
  ];
  return (
    <div className="pad cmpv">
      <header className="v-head">
        <h1 className="v-title">Compare Attempts · {task.title}</h1>
        <span className="chip chip--good">Same ContextPackage {atts[0].ctx}</span>
        <span className="muted">{atts.some(a => ['working', 'starting', 'waiting'].includes(a.state)) ? 'Provisional comparison · some Attempts are still running' : 'Compare evidence before choosing a result'}</span>
      </header>
      <div className="cmpv__grid" style={{ gridTemplateColumns: `120px repeat(${atts.length}, minmax(0, 1fr))` }}>
        <div />
        {atts.map((a) => (
          <div key={a.id} className={`cmpv__col ${s.choice[task.id] === a.id ? 'is-chosen' : ''}`}>
            <div className="row"><span className="astrip__l">{a.label}</span><Agent attempt={a} /></div>
            <Loc attempt={a} parts={['branch', 'host']} forceHost />
            {s.choice[task.id] === a.id && <span className="chip chip--tag chip--good">chosen</span>}
          </div>
        ))}
        {rows.map(([label, cells, bestIdx, fmt]) => (
          <div key={label} className="cmpv__rowwrap" style={{ display: 'contents' }}>
            <div className="cmpv__lab">{label}</div>
            {cells.map((c, i) => {
              const a = atts[i];
              const isPrim = fmt && c != null;
              return <div key={a.id} className={`cmpv__cell ${bestIdx === i ? 'is-best' : ''}`}>{isPrim ? fmt(c, a) : c == null ? <span className="muted">—</span> : c}{bestIdx === i && <i title="Best of the set">★</i>}</div>;
            })}
          </div>
        ))}
        <div className="cmpv__lab">Evidence</div>
        {atts.map((a) => (
          <div key={a.id} className="cmpv__cell">
            <div className="row" style={{ flexWrap: 'wrap' }}>
              <button type="button" className="btn btn--merged btn--sm" disabled={!PROOF_PACKS[a.id]} onClick={() => s.select(a.id, 'proof')}><I n="eye" size={12} />Proof Pack</button>
              <button type="button" className="btn btn--ghost btn--sm" onClick={() => s.openReview(a.id)}>Open diff</button>
            </div>
          </div>
        ))}
      </div>
      <footer className="cmpv__foot">
        {atts.map((a) => <button key={a.id} type="button" className="btn btn--accent" onClick={() => s.choose(task.id, a.id)}>Choose {a.label} · {a.provider === 'local' ? 'Local' : a.provider[0].toUpperCase() + a.provider.slice(1)}</button>)}
        <span className="sp" />
        <input className="input" style={{ maxWidth: 280 }} placeholder="One instruction for both…" value={msg} onChange={(e) => setMsg(e.target.value)} aria-label="Instruction for all Attempts" />
        <button type="button" className="btn btn--ghost" disabled={!msg.trim()} onClick={() => { atts.forEach((a) => s.send({ attemptId: a.id, text: msg })); setMsg(''); }}>Ask both to revise</button>
      </footer>
      <p className="muted cmpv__note">“Choose” records the winner and offers to archive the rest. Nothing is deleted or merged until Integration.</p>
    </div>
  );
}
