// ProofPack.jsx — la revisión empieza por la EVIDENCIA, no por un diff de 3.000 líneas.
// Propuesta Lixbon (no estándar de mercado). Distingue evidencia automática de lo que "dice el agente" y de inferencias.
import { useState } from 'react';
import { useStore, attemptById, taskOf } from '../store';
import { PROOF_PACKS, REVIEW_FILES } from '../data';
import { I, Loc, Agent, StatePill } from '../ui';

const SRC = { auto: ['auto', 'Verified by a command exit code / scanner'], agent: ['agent says', 'Reported by the agent; not independently verified'], inferred: ['inferred', 'Heuristic — treat as a hint'] };
const ST = { pass: ['✓', 'good'], fail: ['✕', 'danger'], skipped: ['–', 'muted'], warn: ['!', 'warn'] };

function Shot({ label, i }) {
  return (
    <figure className="shot">
      <div className="shot__img" style={{ '--h': `${(i * 37) % 360}` }}><span /><span /><span /></div>
      <figcaption>{label}</figcaption>
    </figure>
  );
}

export default function ProofPack() {
  const s = useStore();
  const a = attemptById(s, s.sel.attemptId);
  const task = taskOf(s, a);
  const pp = PROOF_PACKS[a.id];
  const [q, setQ] = useState('');
  if (!pp) {
    return (
      <div className="pad">
        <h1 className="v-title">Proof Pack</h1>
        <div className="empty">No Proof Pack for Attempt {a.label} yet — it is assembled when the Attempt finishes. Evidence so far: {a.files} files, +{a.add}/−{a.del}{a.tests ? `, tests ${a.tests.pass}/${a.tests.total}` : ''}.
          <div style={{ marginTop: 10 }}><button type="button" className="btn btn--ghost btn--sm" onClick={() => s.setView('review')}>Review changes anyway</button></div></div>
      </div>
    );
  }
  const files = REVIEW_FILES[a.id];
  const flagged = pp.review;
  const nHuman = flagged.length + pp.questions.length;
  return (
    <div className="pad pp">
      <header className="v-head">
        <h1 className="v-title">Proof Pack</h1>
        <span className="chip mono" title="A Review always targets Attempt + revision">{task.title} · Attempt {a.label} @ {pp.revision}</span>
        <StatePill attempt={a} /><Agent attempt={a} />
      </header>
      <Loc attempt={a} parts={['branch', 'host']} forceHost />

      <div className="pp__need callout callout--warn">
        <b>What needs a human</b> — {nHuman} item{nHuman === 1 ? '' : 's'}: {flagged.length} file{flagged.length === 1 ? '' : 's'} on a security-sensitive path{pp.questions.length ? `, ${pp.questions.length} open question` : ''}.
        <div className="row" style={{ flexWrap: 'wrap', marginTop: 6 }}>
          {flagged.map((f) => <button key={f} type="button" className="chip chip--warn mono pp__file" onClick={() => s.setView('review')}>{f}</button>)}
        </div>
      </div>

      <div className="pp__grid">
        <section className="pp__c pp__c--wide">
          <h3>What the agent tried</h3>
          <p><b>{pp.objective}.</b> {pp.approach}</p>
        </section>
        <section className="pp__c">
          <h3>What changed</h3>
          <div className="pp__big"><b>{pp.files}</b> files</div>
          <div className="pp__bar"><i className="add" style={{ flex: pp.add }} /><i className="del" style={{ flex: pp.del }} /></div>
          <div className="row"><b className="good">+{pp.add}</b><b className="danger">−{pp.del}</b></div>
          {files && <div className="muted">{files.filter((f) => f.risk === 'high').length} high-risk · {files.filter((f) => f.generated).length} generated</div>}
        </section>

        <section className="pp__c pp__c--wide">
          <h3>What it checked <span className="pp__legend">{Object.values(SRC).map(([k, t]) => <span key={k} title={t} className={`src src--${k.replace(' says', '')}`}>{k}</span>)}</span></h3>
          <table className="tbl"><tbody>
            {pp.validation.map((v) => (
              <tr key={v.name}><td className={ST[v.status][1]}>{ST[v.status][0]}</td><td>{v.name}</td><td className="mono">{v.result}</td><td className="muted">{v.ms}</td><td><span className={`src src--${v.src}`}>{SRC[v.src][0]}</span></td></tr>
            ))}
          </tbody></table>
        </section>
        <section className="pp__c">
          <h3>Security &amp; dependencies</h3>
          <ul className="pp__ul">
            {pp.security.map((x) => <li key={x.name}><span className={ST[x.status][1]}>{ST[x.status][0]}</span> {x.name}<small>{x.detail}</small></li>)}
            {pp.deps.map((d) => <li key={d.name}><span className="info">+</span> dependency <b className="mono">{d.name}</b><small>{d.change}</small></li>)}
            {!pp.deps.length && <li className="muted">No dependency changes.</li>}
          </ul>
        </section>

        <section className="pp__c">
          <h3>What failed</h3>
          {pp.failed.length ? <ul className="pp__ul">{pp.failed.map((f) => <li key={f}><span className="danger">✕</span> {f}</li>)}</ul> : <p className="muted">Nothing failed along the way.</p>}
        </section>
        <section className="pp__c">
          <h3>What it could NOT verify</h3>
          <ul className="pp__ul">{pp.unverified.map((f) => <li key={f}><span className="warn">?</span> {f}</li>)}</ul>
        </section>
        <section className="pp__c">
          <h3>Risk</h3>
          <ul className="pp__ul">{pp.risks.map((r) => <li key={r.text}><span className={`risk risk--${r.level}`}>{r.level}</span> {r.text}</li>)}</ul>
        </section>

        {pp.screenshots.length > 0 && (
          <section className="pp__c pp__c--wide">
            <h3>Visual evidence <span className="muted">· {pp.screenshots.length} screenshots from a known flow</span></h3>
            <div className="pp__shots">{pp.screenshots.map((l, i) => <Shot key={l} label={l} i={i + 1} />)}</div>
          </section>
        )}
        {pp.questions.length > 0 && (
          <section className="pp__c pp__c--wide">
            <h3>Open questions</h3>
            {pp.questions.map((x) => <p key={x} className="pp__q">{x}</p>)}
            <div className="row"><input className="input" placeholder="Answer to the agent…" value={q} onChange={(e) => setQ(e.target.value)} aria-label="Answer" />
              <button type="button" className="btn btn--ghost btn--sm" disabled={!q.trim()} onClick={() => { s.send({ attemptId: a.id, text: q.trim(), mode: 'queue' }); setQ(''); }}>Send</button></div>
          </section>
        )}
      </div>

      <footer className="pp__foot">
        <button type="button" className="btn btn--accent btn--lg" onClick={() => s.setView('review')}>Review changes →</button>
        <button type="button" className="btn btn--ghost btn--lg" onClick={() => s.decide(a.id, 'accepted')} title={`Accepts only revision ${pp.revision}`}>Accept @ {pp.revision}</button>
        <button type="button" className="btn btn--danger btn--lg" onClick={() => s.decide(a.id, 'rejected')}>Reject</button>
        <span className="sp" />
        <span className="muted">Automatic ≠ proven: “architecture is right” and “no regressions” are never claimed here.</span>
      </footer>
    </div>
  );
}
